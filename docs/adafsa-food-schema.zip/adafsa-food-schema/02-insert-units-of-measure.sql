insert into unit_of_measure (id, name, description) values (1, 'g', 'gram');
insert into unit_of_measure (id, name, description) values (2, 'mg', 'milligram');
insert into unit_of_measure (id, name, description) values (3, 'mcg', 'microgram');
insert into unit_of_measure (id, name, description) values (4, 'iu', 'international unit');
insert into unit_of_measure (id, name, description) values (5, 'kcal', 'kilocalories');
insert into unit_of_measure (id, name, description) values (6, 'kj', 'kilojoules');
GO
