DROP TABLE IF EXISTS food_nutrient
GO

drop table if exists ingredient
go

DROP TABLE IF EXISTS nutritional_component
GO

DROP TABLE IF EXISTS nutrient
GO

DROP TABLE IF EXISTS recipe
GO

DROP TABLE IF EXISTS food
GO

DROP TABLE IF EXISTS data_source
GO

DROP TABLE IF EXISTS data_owner
GO

DROP TABLE IF EXISTS unit_of_measure
GO

CREATE TABLE unit_of_measure (
    id INT PRIMARY KEY,
    name NVARCHAR(5) NOT NULL,
    description NVARCHAR(250) NOT NULL
);
GO

CREATE TABLE nutrient (
    id INT PRIMARY KEY,
    name_en NVARCHAR(250) NOT NULL,
    name_ar NVARCHAR(250) NULL,
    unit_of_measure_id INT NOT NULL,
    FOREIGN KEY (unit_of_measure_id) REFERENCES unit_of_measure(id)
);
GO

CREATE TABLE data_owner (
    id INT PRIMARY KEY,
    name NVARCHAR(250) NOT NULL
);
GO

CREATE TABLE data_source (
    id INT PRIMARY KEY,
    name NVARCHAR(250) NOT NULL,
    data_owner_id INT NOT NULL,
    FOREIGN KEY (data_owner_id) REFERENCES data_owner(id)
);
GO

CREATE TABLE food (
    id INT PRIMARY KEY,
    description_en NVARCHAR(250) NOT NULL,
    description_ar NVARCHAR(250) NULL,
    data_source_id INT NOT NULL,
    FOREIGN KEY (data_source_id) REFERENCES data_source(id)
);
GO

CREATE TABLE nutritional_component (
    food_id INT NOT NULL,
    nutrient_id INT NOT NULL,
    quantity DECIMAL(8, 4),
    unit_of_measure_id INT NOT NULL,
    PRIMARY KEY (food_id, nutrient_id),
    FOREIGN KEY (food_id) REFERENCES food(id),
    FOREIGN KEY (nutrient_id) REFERENCES nutrient(id),
    FOREIGN KEY (unit_of_measure_id) REFERENCES unit_of_measure(id)
);
GO

CREATE TABLE recipe (
    id INT PRIMARY KEY,
    food_id INT,
    FOREIGN KEY (food_id) REFERENCES food(id)
);
GO

CREATE TABLE ingredient (
    id INT PRIMARY KEY,
    quantity DECIMAL(8, 4),
    unit_of_measure_id INT NOT NULL,
    recipe_id INT,
    food_id INT,
    FOREIGN KEY (recipe_id) REFERENCES recipe(id),
    FOREIGN KEY (food_id) REFERENCES food(id),
    FOREIGN KEY (unit_of_measure_id) REFERENCES unit_of_measure(id)
);
GO
