insert into data_owner (id, name) values (1, 'ADAFSA');
insert into data_owner (id, name) values (2, 'USDA');
GO

insert into data_source (id, name, data_owner_id) values (1, 'ADAFSA - Emirati Food Consumption Database 2023', 1);
insert into data_source (id, name, data_owner_id) values (2, 'ADAFSA - Kuwaiti Food Consumption Database 2023', 1);
insert into data_source (id, name, data_owner_id) values (3, 'USDA - Legacy', 2);
insert into data_source (id, name, data_owner_id) values (4, 'USDA - Branded', 2);
GO
